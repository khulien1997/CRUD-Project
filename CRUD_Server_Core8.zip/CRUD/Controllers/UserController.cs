﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using CRUD.Models;
using Microsoft.AspNetCore.Cors;

namespace CRUD.Controllers
{
    [ApiController]
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UsersController(AppDbContext context)
        {
            _context = context;
        }

        //For scalability consideration the HTTP methods will be asynchronously called.

        [HttpPost]
        public async Task<ActionResult<UserModel>> CreateUser(UserModel userModel)
        {
            try
            {
                if (userModel == null)
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(userModel.Name))
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(userModel.Address))
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(userModel.Email))
                {
                    return BadRequest();
                }

                if (Validate.validateEmailAddress(userModel.Email) == false)
                {
                    return BadRequest();
                }

                _context.Users.Add(userModel);

                await _context.SaveChangesAsync();

                return Created(string.Empty, userModel);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in creating user record.");
            }
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserModel>>> GetUsers()
        {
            try
            {
                return Ok(await _context.Users.ToListAsync());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in retrieving user record(s).");
            }
        }

        [HttpGet("{userId}")]
        public async Task<ActionResult<UserModel>> GetUser(Guid userId)
        {
            try
            {
                var user = await _context.Users.FindAsync(userId);

                if (user == null) 
                {
                    return NotFound();
                }

                return user;
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in retrieving user record.");
            }
        }

        [HttpPut("{userId}")]
        public async Task<IActionResult> UpdateUser(Guid userId, UserModel userModel)
        {
            try
            {
                if (userModel == null)
                {
                    return BadRequest();
                }

                if (userId != userModel.UserId) 
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(userModel.Name))
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(userModel.Address))
                {
                    return BadRequest();
                }

                if (string.IsNullOrEmpty(userModel.Email))
                {
                    return BadRequest();
                }

                if (Validate.validateEmailAddress(userModel.Email) == false)
                {
                    return BadRequest();
                }

                _context.Entry(userModel).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in updating user record.");
            }
        }

        [HttpDelete("{userId}")]
        public async Task<IActionResult> DeleteUser(Guid userId)
        {
            try
            {
                var user = await _context.Users.FindAsync(userId);

                if (user == null) 
                {
                    return NotFound();
                }

                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch(Exception ex) 
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in deleting user record.");
            }
        }
    }

}
