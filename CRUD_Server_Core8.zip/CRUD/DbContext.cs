﻿using CRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace CRUD
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) 
        { 
        
        }

        public DbSet<UserModel> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=(localDB)\localDB;Initial Catalog=CRUD;Integrated Security=True;");
        }
    }

}
