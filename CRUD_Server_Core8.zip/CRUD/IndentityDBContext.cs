﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


namespace CRUD
{
    public class IndentityDBContext : IdentityDbContext<IdentityUser>
    {
        public IndentityDBContext(DbContextOptions<IndentityDBContext> dbContextOptions) : base(dbContextOptions)
        {
            
        }
    }
}
