﻿using System.ComponentModel.DataAnnotations;

namespace CRUD.Models
{
    //The User Model
    public class UserModel
    {
        //UserId - Unique Identifier
        [Key]
        public Guid UserId { get; set; }

        //User Name
        [Required]
        public string Name { get; set; }

        //User Email
        [Required]
        public string Email { get; set; }

        //User Date of Birth
        [Required]
        public DateTime DOB { get; set; }

        //User Address
        [Required]
        public string Address { get; set; }
    }
}
