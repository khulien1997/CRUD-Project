﻿
using System.Net.Mail;

namespace CRUD
{
    public class Validate
    {
        public static bool validateEmailAddress(string emailAddress)
        {
            try
            {
                var m = new MailAddress(emailAddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}
